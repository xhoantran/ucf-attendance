# Included so that Django's startproject comment runs against the docs directory
